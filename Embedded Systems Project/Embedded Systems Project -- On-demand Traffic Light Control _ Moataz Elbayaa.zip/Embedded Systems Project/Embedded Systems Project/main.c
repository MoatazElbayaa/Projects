/*
 * Embedded Systems Project.c
 *
 * Created: 2022-09-05 3:01:39 AM
 * Author : Moataz Elbayaa
 */ 

//include app.h
#include "Application\app.h"

int main(void)
{
    /* Replace with your application code */
	
	App_init();
	App_start();
	
}




